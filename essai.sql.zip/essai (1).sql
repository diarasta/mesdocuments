-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1:3306
-- Généré le :  jeu. 03 jan. 2019 à 08:42
-- Version du serveur :  5.7.23
-- Version de PHP :  7.1.22

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données :  `essai`
--

-- --------------------------------------------------------

--
-- Structure de la table `affectation`
--

DROP TABLE IF EXISTS `affectation`;
CREATE TABLE IF NOT EXISTS `affectation` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `demande_id` int(11) NOT NULL,
  `date` date NOT NULL,
  KEY `user_id` (`user_id`),
  KEY `demande_id` (`demande_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `commentaire`
--

DROP TABLE IF EXISTS `commentaire`;
CREATE TABLE IF NOT EXISTS `commentaire` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `libelle` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `commentaire`
--

INSERT INTO `commentaire` (`id`, `libelle`) VALUES
(1, 'Avec justificatifs'),
(2, 'Sans justificatifs'),
(3, 'Retour Partiel');

-- --------------------------------------------------------

--
-- Structure de la table `demande`
--

DROP TABLE IF EXISTS `demande`;
CREATE TABLE IF NOT EXISTS `demande` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `description` text CHARACTER SET utf8 COLLATE utf8_general_mysql500_ci,
  `id_typeDemande` int(11) NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `id_status` int(11) NOT NULL DEFAULT '1',
  `id_expediteur` int(11) NOT NULL,
  `objet` varchar(255) NOT NULL,
  `id_direction` int(11) DEFAULT NULL,
  `destinataire_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id_expediteur` (`id_expediteur`),
  KEY `id_status` (`id_status`),
  KEY `id_typeDemande` (`id_typeDemande`),
  KEY `id_direction` (`id_direction`),
  KEY `destinataire_id` (`destinataire_id`)
) ENGINE=InnoDB AUTO_INCREMENT=40 DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `demande`
--

INSERT INTO `demande` (`id`, `description`, `id_typeDemande`, `date`, `id_status`, `id_expediteur`, `objet`, `id_direction`, `destinataire_id`) VALUES
(1, 'dffuguo\r\ndhùhoh\r\ndfdppih fdaoefd  hùohùoùofe  hfoiho', 12, '2018-12-12 14:26:23', 2, 39, 'ddr', 2, 23),
(2, 'dirfin', 12, '2018-12-12 14:43:13', 2, 39, 'dirfin', 3, 42),
(3, 'valider', 12, '2018-12-17 22:10:26', 2, 39, 'sg', 4, 23),
(4, 'f', 13, '2018-12-18 15:18:51', 3, 39, '', 2, NULL),
(5, 'valider', 15, '2018-12-20 08:54:17', 2, 8, 'dd', 1, NULL),
(6, 'wa hanley koumou salam', 12, '2018-12-20 11:15:59', 3, 5, 'ss', 11, 23),
(7, 'en cours', 12, '2018-12-20 11:41:29', 5, 9, 'sss', 6, 23),
(8, 'valider', 13, '2018-12-20 11:44:21', 2, 11, 'f', 2, 23),
(9, 'traiter', 12, '2018-12-20 11:48:20', 2, 13, 's', 9, NULL),
(10, 'ffg', 12, '2018-12-26 17:09:10', 2, 39, 'df', 6, NULL),
(11, 'valider', 12, '2018-12-27 13:54:27', 2, 39, 'essai', 3, 23),
(12, 'en cours', 12, '2018-12-27 16:03:00', 5, 39, 'siop', 7, 23),
(13, 'refuser', 13, '2018-12-27 16:06:57', 4, 39, 'siop', 7, 23),
(14, 'valider', 18, '2018-12-27 19:09:31', 2, 39, 'essai', 5, 24),
(15, 'refuser', 16, '2018-12-27 19:09:52', 4, 39, 'sss', 2, 24),
(16, 'valider', 19, '2018-12-27 19:10:13', 2, 39, 'ssiop', 7, 24),
(17, 're', 20, '2018-12-27 19:10:35', 1, 39, 're', 5, 24),
(18, 'sj', 22, '2018-12-27 19:10:50', 1, 39, 'skk', 10, 24),
(19, 'sbldj', 21, '2018-12-27 19:11:06', 1, 39, 'spj', 7, 24),
(20, 'ddr', 12, '2018-12-30 21:59:34', 1, 39, 'ddr', 2, 42),
(21, 'ddr', 12, '2018-12-30 21:59:34', 1, 39, 'ddr', 2, 42),
(22, 'valider', 12, '2018-12-31 08:41:35', 2, 39, 'ddr', 2, 40),
(23, 'valider', 18, '2018-12-31 09:07:22', 2, 39, 'siop', 7, 24),
(24, '                                                \r\n             Votre site est fonctionnel ? Il marche parfaitement en local, et vous voulez que le monde entier en profite ? Vous êtes au bon endroit, on va voir dans ce chapitre les points à vérifier pour déployer votre site sur un serveur distant.\r\n\r\nL\'objectif de ce chapitre n\'est pas de vous apprendre comment mettre en production un site de façon générale, mais juste de vous mettre le doigt sur les quelques points particuliers auxquels il faut faire attention lors d\'un projet Symfony.\r\n\r\nLa méthodologie est la suivante :\r\n\r\nUploader votre code à jour sur le serveur de production ;\r\n\r\nMettre à jour vos dépendances via Composer ;\r\n\r\nMettre à jour votre base de données ;\r\n\r\nVider le cache.                               ', 15, '2018-12-31 20:24:04', 1, 39, 'virement', 1, NULL),
(25, '                                                \r\n             Votre site est fonctionnel ? Il marche parfaitement en local, et vous voulez que le monde entier en profite ? Vous êtes au bon endroit, on va voir dans ce chapitre les points à vérifier pour déployer votre site sur un serveur distant.\r\n\r\nL\'objectif de ce chapitre n\'est pas de vous apprendre comment mettre en production un site de façon générale, mais juste de vous mettre le doigt sur les quelques points particuliers auxquels il faut faire attention lors d\'un projet Symfony.\r\n\r\nLa méthodologie est la suivante :\r\n\r\nUploader votre code à jour sur le serveur de production ;\r\n\r\nMettre à jour vos dépendances via Composer ;\r\n\r\nMettre à jour votre base de données ;\r\n\r\nVider le cache.                               ', 15, '2018-12-31 20:25:09', 1, 39, 'virement', 1, NULL),
(26, '                                                \r\n             Votre site est fonctionnel ? Il marche parfaitement en local, et vous voulez que le monde entier en profite ? Vous êtes au bon endroit, on va voir dans ce chapitre les points à vérifier pour déployer votre site sur un serveur distant.\r\n\r\nL\'objectif de ce chapitre n\'est pas de vous apprendre comment mettre en production un site de façon générale, mais juste de vous mettre le doigt sur les quelques points particuliers auxquels il faut faire attention lors d\'un projet Symfony.\r\n\r\nLa méthodologie est la suivante :\r\n\r\nUploader votre code à jour sur le serveur de production ;\r\n\r\nMettre à jour vos dépendances via Composer ;\r\n\r\nMettre à jour votre base de données ;\r\n\r\nVider le cache.                               ', 15, '2018-12-31 20:27:29', 1, 39, 'virement', 1, NULL),
(27, '                                                \r\n             Votre site est fonctionnel ? Il marche parfaitement en local, et vous voulez que le monde entier en profite ? Vous êtes au bon endroit, on va voir dans ce chapitre les points à vérifier pour déployer votre site sur un serveur distant.\r\n\r\nL\'objectif de ce chapitre n\'est pas de vous apprendre comment mettre en production un site de façon générale, mais juste de vous mettre le doigt sur les quelques points particuliers auxquels il faut faire attention lors d\'un projet Symfony.\r\n\r\nLa méthodologie est la suivante :\r\n\r\nUploader votre code à jour sur le serveur de production ;\r\n\r\nMettre à jour vos dépendances via Composer ;\r\n\r\nMettre à jour votre base de données ;\r\n\r\nVider le cache.                               ', 15, '2018-12-31 20:28:30', 1, 39, 'virement', 1, NULL),
(28, 'Votre site est fonctionnel ? Il marche parfaitement en local, et vous voulez que le monde entier en profite ? Vous êtes au bon endroit, on va voir dans ce chapitre les points à vérifier pour déployer votre site sur un serveur distant.\r\n\r\nL\'objectif de ce chapitre n\'est pas de vous apprendre comment mettre en production un site de façon générale, mais juste de vous mettre le doigt sur les quelques points particuliers auxquels il faut faire attention lors d\'un projet Symfony.\r\n\r\nLa méthodologie est la suivante :\r\n\r\nUploader votre code à jour sur le serveur de production ;\r\n\r\nMettre à jour vos dépendances via Composer ;\r\n\r\nMettre à jour votre base de données ;\r\n\r\nVider le cache.      ', 12, '2018-12-31 21:31:27', 1, 39, 'objet', 1, NULL),
(29, 'Votre site est fonctionnel ? Il marche parfaitement en local, et vous voulez que le monde entier en profite ? Vous êtes au bon endroit, on va voir dans ce chapitre les points à vérifier pour déployer votre site sur un serveur distant.\r\n\r\nL\'objectif de ce chapitre n\'est pas de vous apprendre comment mettre en production un site de façon générale, mais juste de vous mettre le doigt sur les quelques points particuliers auxquels il faut faire attention lors d\'un projet Symfony.\r\n\r\nLa méthodologie est la suivante :\r\n\r\nUploader votre code à jour sur le serveur de production ;\r\n\r\nMettre à jour vos dépendances via Composer ;\r\n\r\nMettre à jour votre base de données ;\r\n\r\nVider le cache.      ', 12, '2018-12-31 21:33:21', 1, 39, 'objet', 1, NULL),
(30, 'en cours', 12, '2018-12-31 21:51:29', 5, 39, 'siop', 7, 23),
(31, 'en cours', 12, '2018-12-31 21:55:33', 5, 39, 'demande', 7, 23),
(32, 'Votre site est fonctionnel ? Il marche parfaitement en local, et vous voulez que le monde entier en profite ? Vous êtes au bon endroit, on va voir dans ce chapitre les points à vérifier pour déployer votre site sur un serveur distant.\r\n\r\nL\'objectif de ce chapitre n\'est pas de vous apprendre comment mettre en production un site de façon générale, mais juste de vous mettre le doigt sur les quelques points particuliers auxquels il faut faire attention lors d\'un projet Symfony.\r\n\r\nLa méthodologie est la suivante :\r\n\r\nUploader votre code à jour sur le serveur de production ;\r\n\r\nMettre à jour vos dépendances via Composer ;\r\n\r\nMettre à jour votre base de données ;\r\n\r\nVider le cache.', 12, '2018-12-31 22:00:16', 1, 8, 'demande', 4, 23),
(33, 'valider', 12, '2018-12-31 22:04:36', 2, 39, 'demande', 7, 23),
(34, 'refuser', 12, '2019-01-01 18:39:36', 4, 8, 'sg', 4, 23),
(35, '                                                \r\n                      siop                      ', 12, '2019-01-01 19:37:55', 1, 39, 'siop', 7, 23),
(36, '                                                \r\n                                     siop       ', 12, '2019-01-01 19:41:11', 1, 39, 'siop', 7, 23),
(37, 'refuser', 17, '2019-01-01 19:47:14', 4, 39, 'siop', 7, 24),
(38, 'valider', 12, '2019-01-02 12:12:00', 2, 39, 'procedure', 7, 23),
(39, 'refuser', 13, '2019-01-02 13:44:14', 4, 39, 'segl', 4, 23);

-- --------------------------------------------------------

--
-- Structure de la table `demandecree`
--

DROP TABLE IF EXISTS `demandecree`;
CREATE TABLE IF NOT EXISTS `demandecree` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `description` text NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `id_expediteur` int(11) NOT NULL,
  `objet` varchar(255) NOT NULL,
  `id_typedemandeanalysis` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id_expediteur` (`id_expediteur`),
  KEY `id_typedemande` (`id_typedemandeanalysis`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `demandecreebsacase`
--

DROP TABLE IF EXISTS `demandecreebsacase`;
CREATE TABLE IF NOT EXISTS `demandecreebsacase` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date_reception` date NOT NULL,
  `reference` varchar(11) NOT NULL,
  `nom_client` varchar(255) NOT NULL,
  `objet` varchar(255) NOT NULL,
  `suivi` varchar(255) NOT NULL,
  `date_retour` date NOT NULL,
  `id_statut_ofac` int(11) NOT NULL,
  `commentaire` varchar(255) NOT NULL,
  `analyste` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id_statut_ofac` (`id_statut_ofac`),
  KEY `analyste` (`analyste`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `demandecreebsacase`
--

INSERT INTO `demandecreebsacase` (`id`, `date_reception`, `reference`, `nom_client`, `objet`, `suivi`, `date_retour`, `id_statut_ofac`, `commentaire`, `analyste`) VALUES
(1, '2018-12-24', 'salam', 'diamanka', 'ss', 'salam', '2018-12-25', 1, 'salut', 22),
(2, '2018-12-24', 'salam', 'diamanka', 'ss', 'salam', '2018-12-25', 1, 'salut', 22),
(3, '2018-12-25', 'salam', 'diamanka', 'd', 'salam', '2018-12-26', 1, 'salut', 22),
(4, '2018-12-25', 'salam', 'diamanka', 'd', 'salam', '2018-12-26', 1, 'salut', 22),
(5, '2018-12-17', 'salam', 'diamanka', 'ddr', 'salam', '2018-12-18', 1, 'salut', 22),
(6, '2018-12-17', 'salam', 'diamanka', 'ddr', 'salam', '2018-12-18', 1, 'salut', 22),
(7, '2018-12-16', 'salam', 'diamanka', 'ss', 'salam', '2018-12-16', 1, 'salut', 22),
(8, '2018-12-16', 'salam', 'diamanka', 'ss', 'salam', '2018-12-16', 1, 'salut', 22),
(9, '2018-12-20', 'salam', 'diamanka', 'ddr', 'salam', '2018-12-21', 2, 'salut', 22);

-- --------------------------------------------------------

--
-- Structure de la table `demandecreeforce`
--

DROP TABLE IF EXISTS `demandecreeforce`;
CREATE TABLE IF NOT EXISTS `demandecreeforce` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `numero_reference` int(11) NOT NULL,
  `date_reception` date NOT NULL,
  `date_line` varchar(11) NOT NULL,
  `date_traitement` date NOT NULL,
  `date_cloture` date NOT NULL,
  `objet` varchar(255) NOT NULL,
  `id_statut_alerte` int(11) NOT NULL,
  `id_statut_delai` int(11) NOT NULL,
  `nom_client` varchar(255) NOT NULL,
  `contre_partie` varchar(255) NOT NULL,
  `montant` varchar(255) NOT NULL,
  `analyste` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id_statut_alerte` (`id_statut_alerte`),
  KEY `id_statut_delai` (`id_statut_delai`),
  KEY `analyste` (`analyste`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `demandecreeforce`
--

INSERT INTO `demandecreeforce` (`id`, `numero_reference`, `date_reception`, `date_line`, `date_traitement`, `date_cloture`, `objet`, `id_statut_alerte`, `id_statut_delai`, `nom_client`, `contre_partie`, `montant`, `analyste`) VALUES
(1, 1, '2018-12-06', '3', '2018-12-21', '2018-12-14', 'salam', 2, 2, 'diamanka', 'sgbs', '50000000', 22),
(2, 2, '2018-12-13', '3', '2018-12-15', '2018-12-14', 'sg', 1, 1, 'diamanka', 'sgbs', '50000000', 22),
(3, 2, '2018-12-13', '3', '2018-12-15', '2018-12-14', 'sg', 1, 1, 'diamanka', 'sgbs', '50000000', 22);

-- --------------------------------------------------------

--
-- Structure de la table `demandecreeforce2`
--

DROP TABLE IF EXISTS `demandecreeforce2`;
CREATE TABLE IF NOT EXISTS `demandecreeforce2` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `numero_reference` int(11) NOT NULL,
  `date_reception` date NOT NULL,
  `date_line` int(11) NOT NULL,
  `date_traitement` date NOT NULL,
  `date_cloture` date NOT NULL,
  `objet` varchar(255) NOT NULL,
  `id_statut_alerte` int(11) NOT NULL,
  `id_statut_delai` int(11) NOT NULL,
  `nom_client` varchar(255) NOT NULL,
  `analyste` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `analyste` (`analyste`),
  KEY `id_statut_delai` (`id_statut_delai`),
  KEY `id_statut_alerte` (`id_statut_alerte`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `demandecreeforce2`
--

INSERT INTO `demandecreeforce2` (`id`, `numero_reference`, `date_reception`, `date_line`, `date_traitement`, `date_cloture`, `objet`, `id_statut_alerte`, `id_statut_delai`, `nom_client`, `analyste`) VALUES
(1, 2, '2018-12-04', 3, '2018-12-16', '2018-12-13', 'salam', 1, 1, 'diamanka', 22),
(2, 2, '2018-12-04', 3, '2018-12-16', '2018-12-13', 'salam', 1, 1, 'diamanka', 22),
(3, 2, '2018-12-04', 3, '2018-12-16', '2018-12-13', 'salam', 1, 1, 'diamanka', 22);

-- --------------------------------------------------------

--
-- Structure de la table `demandecreeofaccase`
--

DROP TABLE IF EXISTS `demandecreeofaccase`;
CREATE TABLE IF NOT EXISTS `demandecreeofaccase` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `numero_ofaccase` int(11) NOT NULL,
  `date_reception` date NOT NULL,
  `reference` varchar(255) NOT NULL,
  `nom_client` varchar(255) NOT NULL,
  `objet` varchar(255) NOT NULL,
  `suivi` varchar(255) NOT NULL,
  `date_retour` date NOT NULL,
  `id_statut_ofac` int(11) NOT NULL,
  `commentaire` varchar(255) NOT NULL,
  `analyste` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `analyste` (`analyste`),
  KEY `id_statut_ofac` (`id_statut_ofac`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `demandecreeofaccase`
--

INSERT INTO `demandecreeofaccase` (`id`, `numero_ofaccase`, `date_reception`, `reference`, `nom_client`, `objet`, `suivi`, `date_retour`, `id_statut_ofac`, `commentaire`, `analyste`) VALUES
(1, 2, '2018-12-10', 'salam', 'diamanka', 'd', 'salam', '2018-12-26', 1, 'salut', 22),
(2, 2, '2018-12-10', 'salam', 'diamanka', 'd', 'salam', '2018-12-26', 1, 'salut', 22),
(3, 1, '2018-12-18', 'salam', 'diamanka', 'ss', 'salam', '2018-12-26', 1, 'salut', 22);

-- --------------------------------------------------------

--
-- Structure de la table `demandecreesiron`
--

DROP TABLE IF EXISTS `demandecreesiron`;
CREATE TABLE IF NOT EXISTS `demandecreesiron` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date_reception` date NOT NULL,
  `gestionnaire` varchar(255) NOT NULL,
  `matricule_agent` int(255) NOT NULL,
  `agence` int(255) NOT NULL,
  `matricule_client` varchar(255) NOT NULL,
  `nom_client` varchar(255) NOT NULL,
  `date_retour` date NOT NULL,
  `duree` int(11) NOT NULL,
  `deadline` int(11) NOT NULL,
  `id_commentaire` int(11) NOT NULL,
  `id_statut` int(11) NOT NULL,
  `date_scoring` date NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id_commentaire` (`id_commentaire`),
  KEY `id_statut` (`id_statut`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `demandecreevirement`
--

DROP TABLE IF EXISTS `demandecreevirement`;
CREATE TABLE IF NOT EXISTS `demandecreevirement` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `numero_demande` int(11) NOT NULL,
  `date_reception` date NOT NULL,
  `nom_client` varchar(255) NOT NULL,
  `numero_compte` varchar(255) NOT NULL,
  `gestionnaire` varchar(255) NOT NULL,
  `pays` text NOT NULL,
  `donneurs` varchar(255) NOT NULL,
  `motif` varchar(255) NOT NULL,
  `montant` varchar(255) NOT NULL,
  `date_retour` date NOT NULL,
  `id_validation` int(11) NOT NULL,
  `analyste` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id_validation` (`id_validation`),
  KEY `analyste` (`analyste`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `demandecreevirement`
--

INSERT INTO `demandecreevirement` (`id`, `numero_demande`, `date_reception`, `nom_client`, `numero_compte`, `gestionnaire`, `pays`, `donneurs`, `motif`, `montant`, `date_retour`, `id_validation`, `analyste`) VALUES
(1, 172, '2018-12-16', 'diamanka', '11111111111', 'malick', 'espagne', 'diamanka', 'transaction', '100000000', '2018-12-22', 1, 22);

-- --------------------------------------------------------

--
-- Structure de la table `direction`
--

DROP TABLE IF EXISTS `direction`;
CREATE TABLE IF NOT EXISTS `direction` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `libelle` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `direction`
--

INSERT INTO `direction` (`id`, `libelle`) VALUES
(1, 'conformite'),
(2, 'ddr'),
(3, 'dirfin'),
(4, 'segl'),
(5, 'dtb'),
(6, 'dce'),
(7, 'siop'),
(8, 'dcpp'),
(9, 'dmcq'),
(10, 'informatique'),
(11, 'comptabilite');

-- --------------------------------------------------------

--
-- Structure de la table `pieces`
--

DROP TABLE IF EXISTS `pieces`;
CREATE TABLE IF NOT EXISTS `pieces` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fichier` varchar(255) DEFAULT NULL,
  `id_demande` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id_demande` (`id_demande`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `pieces`
--

INSERT INTO `pieces` (`id`, `fichier`, `id_demande`) VALUES
(1, 'Capture.PNG', 2),
(2, 'Cartographie des Demandes.xlsx', 1),
(3, 'Capture.PNG', 2),
(4, 'Capture.PNG', 3),
(5, 'Cours_php.pdf', 32),
(6, 'Cours_php.pdf', 33),
(7, 'Capture.PNG', 34),
(8, 'Capture.PNG', 35),
(9, 'Cours_php.pdf', 36),
(10, 'Cours_php.pdf', 37),
(11, 'Capture.PNG', 38),
(12, 'Admin  CONFORMITE.csv', 39),
(13, 'Admin  CONFORMITE.pdf', 39),
(14, 'Admin  CONFORMITE.xlsx', 39);

-- --------------------------------------------------------

--
-- Structure de la table `piecess`
--

DROP TABLE IF EXISTS `piecess`;
CREATE TABLE IF NOT EXISTS `piecess` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fichier` varchar(255) DEFAULT NULL,
  `id_demandecree` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id_demandecree` (`id_demandecree`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `piecess`
--

INSERT INTO `piecess` (`id`, `fichier`, `id_demandecree`) VALUES
(2, 'Capture.PNG', 6),
(3, 'Capture.PNG', 7),
(4, 'Capture.PNG', 8),
(5, 'Capture.PNG', 9);

-- --------------------------------------------------------

--
-- Structure de la table `pole`
--

DROP TABLE IF EXISTS `pole`;
CREATE TABLE IF NOT EXISTS `pole` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `libelle` varchar(150) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `pole`
--

INSERT INTO `pole` (`id`, `libelle`) VALUES
(1, 'conformite'),
(2, 'amlft_analysis'),
(3, 'dealflow');

-- --------------------------------------------------------

--
-- Structure de la table `role`
--

DROP TABLE IF EXISTS `role`;
CREATE TABLE IF NOT EXISTS `role` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nom_role` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `role`
--

INSERT INTO `role` (`id`, `nom_role`) VALUES
(1, 'Admin'),
(2, 'Responsable Pole'),
(3, 'Agent'),
(4, 'User'),
(5, 'GC');

-- --------------------------------------------------------

--
-- Structure de la table `status`
--

DROP TABLE IF EXISTS `status`;
CREATE TABLE IF NOT EXISTS `status` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `libelle` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `status`
--

INSERT INTO `status` (`id`, `libelle`) VALUES
(1, 'Reçue'),
(2, 'Valider'),
(3, 'En attente de retour d\'information'),
(4, 'Refuser'),
(5, 'En cours de traitement');

-- --------------------------------------------------------

--
-- Structure de la table `statut_alerte`
--

DROP TABLE IF EXISTS `statut_alerte`;
CREATE TABLE IF NOT EXISTS `statut_alerte` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `libelle` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `statut_alerte`
--

INSERT INTO `statut_alerte` (`id`, `libelle`) VALUES
(1, 'liberee'),
(2, 'bloque'),
(3, 'bloque puis retourne'),
(4, 'bloque puis libere'),
(5, 'en cours');

-- --------------------------------------------------------

--
-- Structure de la table `statut_delai`
--

DROP TABLE IF EXISTS `statut_delai`;
CREATE TABLE IF NOT EXISTS `statut_delai` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `libelle` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `statut_delai`
--

INSERT INTO `statut_delai` (`id`, `libelle`) VALUES
(1, 'dans le delai'),
(2, 'hors delai');

-- --------------------------------------------------------

--
-- Structure de la table `statut_ofac`
--

DROP TABLE IF EXISTS `statut_ofac`;
CREATE TABLE IF NOT EXISTS `statut_ofac` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `libelle` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `statut_ofac`
--

INSERT INTO `statut_ofac` (`id`, `libelle`) VALUES
(1, 'fermer'),
(2, 'en cours');

-- --------------------------------------------------------

--
-- Structure de la table `typedemande`
--

DROP TABLE IF EXISTS `typedemande`;
CREATE TABLE IF NOT EXISTS `typedemande` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `libelle` varchar(255) NOT NULL,
  `delai` int(11) DEFAULT NULL,
  `id_pole` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id_pole` (`id_pole`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `typedemande`
--

INSERT INTO `typedemande` (`id`, `libelle`, `delai`, `id_pole`) VALUES
(12, 'Procedure', NULL, 1),
(13, 'Instruction', NULL, 1),
(14, 'Note d\'information', NULL, 1),
(15, 'Virement sup à 50M', NULL, 2),
(16, 'Operation Trade', NULL, 3),
(17, 'Virement Egypte', NULL, 3),
(18, 'KYC hors PPE Remediation', NULL, 3),
(19, 'KYC hors PPE Flux', NULL, 3),
(20, 'PPE Remediation', NULL, 3),
(21, 'PPE Flux ', NULL, 3),
(22, 'Correspondance Bancaire', NULL, 3),
(23, 'Envoi de justificatifs', NULL, 2);

-- --------------------------------------------------------

--
-- Structure de la table `typedemandeanalysis`
--

DROP TABLE IF EXISTS `typedemandeanalysis`;
CREATE TABLE IF NOT EXISTS `typedemandeanalysis` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `libelle` varchar(255) NOT NULL,
  `id_pole` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id_pole` (`id_pole`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `typedemandeanalysis`
--

INSERT INTO `typedemandeanalysis` (`id`, `libelle`, `id_pole`) VALUES
(1, 'Bsa Case', 2),
(2, 'Ofac Case', 2),
(3, 'Virement sup à 50M', 2),
(4, 'Force 1', 2),
(5, 'Force 2', 2);

-- --------------------------------------------------------

--
-- Structure de la table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `id_role` int(11) NOT NULL,
  `id_pole` int(11) DEFAULT NULL,
  `direction_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id_role` (`id_role`),
  KEY `id_pole` (`id_pole`),
  KEY `direction_id` (`direction_id`)
) ENGINE=InnoDB AUTO_INCREMENT=44 DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `users`
--

INSERT INTO `users` (`id`, `username`, `email`, `password`, `id_role`, `id_pole`, `direction_id`) VALUES
(1, 'admin', 'admin@admin.com', 'admin', 1, NULL, 0),
(2, 'Responsable Pole analysis', 'responsableanalysis@responsable.com', 'responsable', 2, 2, 1),
(3, 'Responsable Pole conformite', 'responsableconformite@responsable.com', 'responsable', 2, 1, 1),
(4, 'Responsable Pole dealflow', 'responsabledealflow@responsable.com', 'responsable', 2, 3, 1),
(5, 'comptabilite', 'comptabilite@comptabilite.com', 'comptabilite', 4, NULL, 11),
(6, 'informatique', 'informatique@informatique.com', 'informatique', 4, NULL, 10),
(7, 'reseaux', 'reseaux@reseaux.com', 'reseaux', 4, NULL, 0),
(8, 'sg', 'sg@sg.com', 'sg', 4, NULL, 0),
(9, 'dce', 'dce@dce.com', 'dce', 4, NULL, 0),
(10, 'dtb', 'dtb@dtb.com', 'dtb', 4, NULL, 0),
(11, 'ddr', 'ddr@ddr.com', 'ddr', 4, NULL, 0),
(12, 'filiales', 'filiales@filiales.com', 'filiales', 4, NULL, 0),
(13, 'dmcq', 'dmcq@dmcq.com', 'dmcq', 4, NULL, 0),
(14, 'fcuparis', 'fcuparis@fcuparis.com', 'fcuparis', 4, NULL, 0),
(15, 'scss', 'scss@scss.com', 'scss', 4, NULL, 0),
(16, 'poi', 'poi@poi.com', 'poi', 4, NULL, 0),
(17, 'pod', 'pod@pod.com', 'pod', 4, NULL, 0),
(18, 'divers', 'divers@divers.com', 'divers', 4, NULL, 0),
(19, 'bsacase', 'bsacase@bsacase.com', 'bsacase', 4, NULL, 0),
(20, 'ofaccase', 'ofaccase@ofaccase.com', 'ofaccase', 4, NULL, 0),
(21, 'forces', 'forces@forces.com', 'forces', 4, NULL, 0),
(22, 'agent analysis', 'agentanalysis@agentanalysis.com', 'agentanalysis', 3, 2, 0),
(23, 'agent conformite', 'agentconformite@agentconformite.com', 'agentconformite', 3, 1, 0),
(24, 'agent dealflow', 'agentdealflow@agentdealflow.com', 'agentdealflow', 3, 3, 0),
(37, 'gc', 'gc@gc', 'gc', 5, NULL, 0),
(38, 'gc', 'gc@gc.com', 'gc', 5, NULL, 0),
(39, 'siop', 'siop@siop.com', 'siop', 4, NULL, 0),
(40, 'baye', 'baye@baye.com', 'baye', 3, 1, 1),
(42, 'yaye', 'yaye@yaye.com', 'yaye', 3, 1, 1),
(43, 'agent dealflow 2', 'agentdealflow2@agentdealflow2.com', 'agentdealflow2', 3, 3, 1);

-- --------------------------------------------------------

--
-- Structure de la table `validation`
--

DROP TABLE IF EXISTS `validation`;
CREATE TABLE IF NOT EXISTS `validation` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `libelle` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `validation`
--

INSERT INTO `validation` (`id`, `libelle`) VALUES
(1, 'valide'),
(2, 'en cours');

--
-- Contraintes pour les tables déchargées
--

--
-- Contraintes pour la table `affectation`
--
ALTER TABLE `affectation`
  ADD CONSTRAINT `affectation_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `affectation_ibfk_2` FOREIGN KEY (`demande_id`) REFERENCES `demande` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Contraintes pour la table `demande`
--
ALTER TABLE `demande`
  ADD CONSTRAINT `demande_ibfk_1` FOREIGN KEY (`id_status`) REFERENCES `status` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `demande_ibfk_2` FOREIGN KEY (`id_expediteur`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `demande_ibfk_3` FOREIGN KEY (`id_typeDemande`) REFERENCES `typedemande` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `demande_ibfk_4` FOREIGN KEY (`destinataire_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Contraintes pour la table `demandecree`
--
ALTER TABLE `demandecree`
  ADD CONSTRAINT `demandecree_ibfk_2` FOREIGN KEY (`id_expediteur`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `demandecree_ibfk_3` FOREIGN KEY (`id_typedemandeanalysis`) REFERENCES `typedemandeanalysis` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Contraintes pour la table `demandecreebsacase`
--
ALTER TABLE `demandecreebsacase`
  ADD CONSTRAINT `demandecreebsacase_ibfk_1` FOREIGN KEY (`analyste`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `demandecreebsacase_ibfk_2` FOREIGN KEY (`id_statut_ofac`) REFERENCES `statut_ofac` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Contraintes pour la table `demandecreeforce`
--
ALTER TABLE `demandecreeforce`
  ADD CONSTRAINT `demandecreeforce_ibfk_1` FOREIGN KEY (`analyste`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `demandecreeforce_ibfk_2` FOREIGN KEY (`id_statut_alerte`) REFERENCES `statut_alerte` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `demandecreeforce_ibfk_3` FOREIGN KEY (`id_statut_delai`) REFERENCES `statut_delai` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Contraintes pour la table `demandecreeforce2`
--
ALTER TABLE `demandecreeforce2`
  ADD CONSTRAINT `demandecreeforce2_ibfk_1` FOREIGN KEY (`analyste`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `demandecreeforce2_ibfk_2` FOREIGN KEY (`id_statut_delai`) REFERENCES `statut_delai` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `demandecreeforce2_ibfk_3` FOREIGN KEY (`id_statut_alerte`) REFERENCES `statut_alerte` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Contraintes pour la table `demandecreeofaccase`
--
ALTER TABLE `demandecreeofaccase`
  ADD CONSTRAINT `demandecreeofaccase_ibfk_1` FOREIGN KEY (`analyste`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `demandecreeofaccase_ibfk_2` FOREIGN KEY (`id_statut_ofac`) REFERENCES `statut_ofac` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Contraintes pour la table `demandecreesiron`
--
ALTER TABLE `demandecreesiron`
  ADD CONSTRAINT `demandecreesiron_ibfk_1` FOREIGN KEY (`id_statut`) REFERENCES `statut_ofac` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `demandecreesiron_ibfk_2` FOREIGN KEY (`id_commentaire`) REFERENCES `commentaire` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Contraintes pour la table `demandecreevirement`
--
ALTER TABLE `demandecreevirement`
  ADD CONSTRAINT `demandecreevirement_ibfk_1` FOREIGN KEY (`id_validation`) REFERENCES `validation` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `demandecreevirement_ibfk_2` FOREIGN KEY (`analyste`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Contraintes pour la table `pieces`
--
ALTER TABLE `pieces`
  ADD CONSTRAINT `pieces_ibfk_1` FOREIGN KEY (`id_demande`) REFERENCES `demande` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Contraintes pour la table `piecess`
--
ALTER TABLE `piecess`
  ADD CONSTRAINT `piecess_ibfk_1` FOREIGN KEY (`id_demandecree`) REFERENCES `demandecree` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Contraintes pour la table `typedemande`
--
ALTER TABLE `typedemande`
  ADD CONSTRAINT `typedemande_ibfk_1` FOREIGN KEY (`id_pole`) REFERENCES `pole` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Contraintes pour la table `typedemandeanalysis`
--
ALTER TABLE `typedemandeanalysis`
  ADD CONSTRAINT `typedemandeanalysis_ibfk_1` FOREIGN KEY (`id_pole`) REFERENCES `pole` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Contraintes pour la table `users`
--
ALTER TABLE `users`
  ADD CONSTRAINT `users_ibfk_1` FOREIGN KEY (`id_role`) REFERENCES `role` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `users_ibfk_2` FOREIGN KEY (`id_pole`) REFERENCES `pole` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
